/*
 * Class: CMSC203 
 * Instructor:Khandan Monshi
 * Description: (Give a brief description for each Class)
 * Due: 02/26/2024
 * Platform/compiler:
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   David Icaza
*/

public class PatientDriverApp 
{
	public static void main(String[] args)
	{
		
		//This applies to the first constructor
		Patient p1 = new Patient();
		p1.setfName("Jenny");
		p1.setmName("Elaine");
		p1.setlName("Santori");
		p1.setAddress("123 Main Street");
		p1.setCity("MyTown");
		p1.setState("CA");
		p1.setZipCode("01234");
		p1.setEConName("Bill Santori");
		p1.setEConPhone("777-555-1212");
		
		//This applies to the second constructor
		Patient p2 = new Patient("Jenny", "Elaine", "Santori");
		p2.setAddress("123 Main Street");
		p2.setCity("MyTown");
		p2.setState("CA");
		p2.setZipCode("01234");
		p2.setEConName("Bill Santori");
		p2.setEConPhone("777-555-1212");
		
		//This applies to the third constructor
		Patient p3 = new Patient("Jenny", "Elaine", "Santori",
				"123 Main Street", "MyTown", "CA", "01234",
				"", "Bill Santori", "777-555-1212");
		
		//This is the first procedure for the first constructor
		Procedure pr1_1 = new Procedure();
		pr1_1.setpName("Physical Exam");
		pr1_1.setpDate("7/20/2019");
		pr1_1.setPractitioner("Dr. Irvine");
		pr1_1.setCharge(3250.00);
		
		//This is the second procedure for the first constructor
		Procedure pr1_2 = new Procedure();
		pr1_2.setpName("X-ray");
		pr1_2.setpDate("7/20/2019");
		pr1_2.setPractitioner("Dr. Jamison");
		pr1_2.setCharge(5500.43);
		
		//This is the third procedure for the first constructor
		Procedure pr1_3 = new Procedure();
		pr1_3.setpName("Blood Test");
		pr1_3.setpDate("7/20/2019");
		pr1_3.setPractitioner("Dr. Smith");
		pr1_3.setCharge(1400.75);
		
		//This is the first procedure for the second constructor
		Procedure pr2_1 = new Procedure("Physical Exam", "7/20/2019");
		pr2_1.setPractitioner("Dr. Irvine");
		pr2_1.setCharge(3250.00);
		
		//This is the second procedure for the second constructor
		Procedure pr2_2 = new Procedure("X -ray", "7/20/2019");
		pr2_2.setPractitioner("Dr. Jamison");
		pr2_2.setCharge(5500.43);
		
		//This is the third procedure for the second constructor
		Procedure pr2_3 = new Procedure("Blood Test", "7/20/2019");
		pr2_3.setPractitioner("Dr. Smith");
		pr2_3.setCharge(1400.75);
		
		//This is the first procedure for the third constructor
		Procedure pr3_1 = new Procedure ("Physical Exam", "7/20/2019", "Dr. Irvine",
				3250.0);
		
		//This is the second procedure for the third constructor
		Procedure pr3_2 = new Procedure ("X-ray", "7/20/2019", "Dr. Jamison",
				5500.43);
		
		//This is the third procedure for the third constructor
		Procedure pr3_3 = new Procedure("Blood Test", "7/20/2019", "Dr. Smith",
				1400.75);
		
		//The following is all for the first constructor
		System.out.println("(First Constructor)");
		displayPatient(p1);
		
		displayProcedure(pr1_1);
		displayProcedure(pr1_2);
		displayProcedure(pr1_3);
		
		double totalCharges = calculateTotalCharges(pr1_1, pr1_2, pr1_3);
		System.out.printf("Total Charges: $%.2f%n", totalCharges);
		
		System.out.println("\nStudent Name: David Icaza");
		System.out.println("MC#: M21133494");
		System.out.println("Due Date: 2/26/2024");
		System.out.println();
		System.out.println();
		System.out.println();
		
		//The following is all for the second constructor
		System.out.println("(Second Constructor)");
		displayPatient(p2);
		
		displayProcedure(pr2_1);
		displayProcedure(pr2_2);
		displayProcedure(pr2_3);
		
		double totalCharges2 = calculateTotalCharges(pr2_1, pr2_2, pr2_3);
		System.out.printf("Total Charges: $%.2f%n", totalCharges2);
		
		System.out.println("\nStudent Name: David Icaza");
		System.out.println("MC#: M21133494");
		System.out.println("Due Date: 2/26/2024");
		System.out.println();
		System.out.println();
		System.out.println();
		
		//The following is all for the third constructor
		System.out.println("(Third Constructor)");
		displayPatient(p3);
		
		displayProcedure(pr3_1);
		displayProcedure(pr3_2);
		displayProcedure(pr3_3);
		
		double totalCharges3 = calculateTotalCharges(pr2_1, pr2_2, pr2_3);
		System.out.printf("Total Charges: $%.2f%n", totalCharges3);
		
		System.out.println("\nStudent Name: David Icaza");
		System.out.println("MC#: M21133494");
		System.out.println("Due Date: 2/26/2024");
		
	}
	
	//Method to display patient information
	public static void displayPatient(Patient pt)
	{
		System.out.println("Patient info: ");
		System.out.println(pt.toString());
	}
	
	//Method to display procedure information
	public static void displayProcedure(Procedure pr)
	{
		System.out.println(pr.toString());
	}
	
	//Method to calculate total charges of procedures
	public static double calculateTotalCharges(Procedure pr1,
			Procedure pr2, Procedure pr3)
	{
		double totalCharges = 0.0;
		
		totalCharges += pr1.getCharge();
		totalCharges += pr2.getCharge();
		totalCharges += pr3.getCharge();
		
		return totalCharges;
	}
}
