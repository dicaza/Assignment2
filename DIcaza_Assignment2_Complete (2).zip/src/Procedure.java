/*
 * Class: CMSC203 
 * Instructor:Khandan Monshi
 * Description: (Give a brief description for each Class)
 * Due: 02/26/2024
 * Platform/compiler:
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   David Icaza
*/

public class Procedure 
{
	//fields or attributes
	private String pName;
	private String pDate;
	private String practitioner;
	private double charge;
	
	//Constructors
	public Procedure()
	{
		pName = "N/A";
		pDate = "N/A";
		practitioner = "N/A";
		charge = 0.0;
	}
	
	public Procedure (String n, String d)
	{
		pName = n;
		pDate = d;
	}
	
	public Procedure (String pName, String pDate, 
			String practitioner, double charge)
	{
		this.pName = pName;
		this.pDate = pDate;
		this.practitioner = practitioner;
		this.charge = charge;
	}
	
	//Accesor or getter
	public String getpName()
	{
		return pName;
	}
	
	public String getpDate()
	{
		return pDate;
	}
	
	public String getPractitioner()
	{
		return practitioner;
	}
	
	public double getCharge()
	{
		return charge;
	}
	
	//Mutator or Setter
	public void setpName(String n)
	{
		pName = n;
	}
	
	public void setpDate(String d)
	{
		pDate = d;
	}
	
	public void setPractitioner(String prac)
	{
		practitioner = prac;
	}
	
	public void setCharge(double c)
	{
		charge = c;
	}
	
	//toString method
	public String toString()
	{
		return ("        Procedure: " + pName +
				"\n        ProcedureDate: " + pDate +
				"\n        Practitioner: " + practitioner + 
				"\n        Charge: " + charge);
	}
}
