/*
 * Class: CMSC203 
 * Instructor:Khandan Monshi
 * Description: (Give a brief description for each Class)
 * Due: 02/26/2024
 * Platform/compiler:
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   David Icaza
*/

public class Patient 
{
	//fields or attributes
	private String fName;
	private String mName;
	private String lName;
	
	private String address;
	private String city;
	private String state;
	private String zipCode;
	
	private String phone;
	private String eConName;
	private String eConPhone;
	
	//No-arg Constructor
	public Patient()
	{
		fName = "N/A";
		mName = "N/A";
		lName = "N/A";
		address = "N/A";
		city = "N/A";
		state = "N/A";
		zipCode = "N/A";
		phone = "N/A";
		eConName = "N/A";
		eConPhone = "N/A";
	}
	
	//constructor that initalizes patient's names
	public Patient (String first, String middle, String last)
	{
		fName = first;
		mName = middle;
		lName = last;
	}
	
	//constructor that initializes all attribute of the patient's address
	public Patient (String fName, String mName, String lName,
			String address, String city, String state, 
			String zipCode, String phone, String eConName, String eConPhone)
	{
		this.fName = fName;
		this.mName = mName;
		this.lName = lName;
		this.address = address;
		this.city = city;
		this.state = state;
		this.zipCode = zipCode;
		this.phone = phone;
		this.eConName = eConName;
		this.eConPhone = eConPhone;
	}
	
	//Accessors or Getters
	public String getfName()
	{
		return fName;
	}
	
	public String getmName()
	{
		return mName;
	}
	
	public String getlName()
	{
		return lName;
	}
	
	public String getAddress()
	{
		return address;
	}
	
	public String getCity()
	{
		return city;
	}
	
	public String getState()
	{
		return state;
	}
	
	public String getZipCode()
	{
		return zipCode;
	}
	
	public String getPhone()
	{
		return phone;
	}
	
	public String getEConName()
	{
		return eConName;
	}
	
	public String getEConPhone()
	{
		return eConPhone;
	}
	
	//Mutators or Setters
	public void setfName(String f)
	{
		fName = f;
	}
	
	public void setmName(String m)
	{
		mName = m;
	}
	
	public void setlName(String l)
	{
		lName = l;
	}
	
	public void setAddress(String a)
	{
		address = a;
	}
	
	public void setCity(String c)
	{
		city = c;
	}
	
	public void setState(String s)
	{
		state = s;
	}
	
	public void setZipCode(String z)
	{
		zipCode = z;
	}
	
	public void setPhone(String p)
	{
		phone = p;
	}
	
	public void setEConName(String ecn)
	{
		eConName = ecn;
	}
	
	public void setEConPhone(String ecp)
	{
		eConPhone = ecp;
	}
	
	//Methods binding attributes together
	public String buildFullName()
	{
		String fullName = fName + " " + mName + " " +lName;
		return fullName;
	}
	
	public String buildAddress()
	{
		String fullAddress = address + " " + city + " " + state
				+ " " + zipCode;
		return fullAddress;
	}
	
	public String buildEmergencyContact()
	{
		String emergencyContact = eConName + " " + eConPhone;
		return emergencyContact;
	}
	
	//toString method to display all info of the patient
	//this method is public and displays all information
	public String toString()
	{
		return ("  Name: " + buildFullName() +
				"\n  Address: " + buildAddress() +
				"\n  Emergency Contact: " + buildEmergencyContact());
	}
}
